import os

from crontab import CronTab

LINUX_USER = 'manu'
MAX_UPDATE_INTERVAL = 2

def create_cron_job(cron_job_file, interval):
    """
    Creates a new cron job that will run a python script at every `interval`
    minutes.

    :param cron_job_file: the absolute file path of the script to be run.
    :param interal: the time interval at which the cron job is supposed to run.
    """

    print "Setting cron job at: ", interval
    tab = CronTab(user=LINUX_USER)
    cron_job_file_path = os.path.join(os.path.abspath('.'), cron_job_file)

    cmd = 'python ' + cron_job_file_path
    cron_job = tab.new(cmd)
    cron_job.minute.every(interval)

    tab.write()
    print tab.render()

if __name__ == "__main__":
    create_cron_job('update_checker_cron_job.py', MAX_UPDATE_INTERVAL)





