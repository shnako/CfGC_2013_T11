import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "freelancers_service.settings")
from datetime import datetime, timedelta
import pytz

from core.models import TemporaryJobs
from core.models import FinishedJobs
from core.cron_scheduler import MAX_UPDATE_INTERVAL

# TODO: log any errors that might occur
def move_job_to_finished(job):
    """
    Moves a TemporaryJobs object to FinishedJobs.
    :param job: the job to be moved.
    """
    try:

        # Add the Job to the finished ones
        FinishedJobs.objects.create(
            user=job.user,
            start_time=job.start_time,
            end_time=job.last_report,
            task_description='Undefined',
            status="TIMED_OUT",
        )

        # Update the owed amount
        wtime_in_seconds = (job.last_report-job.start_time).total_seconds()
        pay_rate_per_second = job.user.pay_rate / 3600
        job.user.amount_owed += pay_rate_per_second * wtime_in_seconds
        job.user.save()

    except Exception as e:
        pass

def check_if_job_has_timed_out():
    """
    Iterate though all the running jobs (TemporaryJobs) and check if any of
    them has timed out.
    """
    temp_jobs = TemporaryJobs.objects.all()
    for temp_job in temp_jobs:
        if datetime.now(pytz.utc) - temp_job.last_report > timedelta(minutes=MAX_UPDATE_INTERVAL):
            move_job_to_finished(temp_job)
            temp_job.delete()

check_if_job_has_timed_out()
