from django.http import Http404
from rest_framework import authentication
from rest_framework import exceptions

from core.models import Accounts

class LWAuthBackend(authentication.BaseAuthentication):
    """
    Authentication class.
    """

    def authenticate(self, request):
        """
        Performs the user authentication.

        :param request: HTTP request.
        :returns: an Accounts object if the user is successfully authenticated
        :raises: Http404 if the user does not exist.
                 exceptions.PermissionDenied() if the user is disabled.
        """
        username = request.META.get('HTTP_X_USERNAME')
        password = request.META.get('HTTP_X_PASSWORD')

        try:
            user = Accounts.objects.get(user=username, password=password)
            if not user.enabled:
                raise exceptions.PermissionDenied()
        except Accounts.DoesNotExist:
            raise Http404

        return (user, None)
