from __future__ import unicode_literals

from django.db import models

class Accounts(models.Model):
    id = models.IntegerField(primary_key=True)
    user = models.CharField(max_length=9L, unique=True, db_column='User')
    password = models.CharField(max_length=512L, db_column='Password')
    pay_rate = models.FloatField(db_column='PayRate')
    amount_owed = models.FloatField(db_column='AmountOwed')
    enabled = models.IntegerField(db_column='Enabled')
    email = models.CharField(max_length=128L, db_column='Email')

    class Meta:
        db_table = 'Accounts'

class TemporaryJobs(models.Model):
    user = models.ForeignKey(
        Accounts,
        unique=True, db_column='User',
        related_name='temp_jobs'
    )
    start_time = models.DateTimeField(db_column='StartTime')
    last_report = models.DateTimeField(db_column='LastReport')

    class Meta:
        db_table = 'TemporaryJobs'

class FinishedJobs(models.Model):
    user = models.ForeignKey(Accounts, db_column='User', related_name='finished_jobs')
    start_time = models.DateTimeField(db_column='StartTime')
    end_time = models.DateTimeField(db_column='EndTime')
    task_description = models.CharField(
        max_length=4000,
        null=False, blank=False,
        db_column='TaskDescription',
    )
    status = models.CharField(max_length=128, db_column='Status')

    class Meta:
        db_table = 'FinishedJobs'
