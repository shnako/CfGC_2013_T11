from rest_framework import serializers

from core.models import TemporaryJobs
from core.models import FinishedJobs
from core.models import Accounts

class TemporaryJobsSerializer(serializers.ModelSerializer):
    class Meta:
        model =  TemporaryJobs
        read_only_fields = ('user', 'start_time', 'last_report', )

class FinishedJobsSerializer(serializers.ModelSerializer):
    class Meta:
        model = FinishedJobs

class AccountsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Accounts



