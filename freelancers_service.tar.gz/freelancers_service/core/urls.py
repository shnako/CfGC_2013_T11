
from django.conf.urls import patterns, url
from rest_framework.urlpatterns import format_suffix_patterns

from core import views

urlpatterns = patterns('',
        url(r'^start-job/$',
           views.JobStarter.as_view(),
           name='job-start'),

        url(r'^update-job/$',
           views.JobUpdater.as_view(),
           name='job-update'),

        url(r'^stop-job/$',
           views.JobTerminator.as_view(),
           name='job-stop'),

        url(r'^check-credentials/$',
           views.CredentialsChecker.as_view(),
           name='credentials-check'),
)

urlpatterns = format_suffix_patterns(urlpatterns)
