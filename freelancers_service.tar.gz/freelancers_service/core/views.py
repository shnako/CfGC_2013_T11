import datetime
import pytz

from django.http import Http404
from rest_framework import generics
from rest_framework import mixins
from rest_framework import status
from rest_framework import exceptions
from rest_framework.response import Response

from core.models import TemporaryJobs
from core.models import FinishedJobs
from core.models import Accounts
from core.serializers import TemporaryJobsSerializer
from core.serializers import AccountsSerializer
from core.auth_backend import LWAuthBackend

def get_now_utc_datetime():
    """
    Obtains the current UTC datetime.

    :rtype: a datetime object.
    """
    return datetime.datetime.now(pytz.utc)

class JobStarter(generics.CreateAPIView):
    """
    Handles the requests that start a new job.
    """

    serializer_class = TemporaryJobsSerializer
    authentication_classes = (LWAuthBackend,)

    def pre_save(self, obj):
        """
        Before adding the new request object to the database
        add to the object the user, the start_time and make
        the last_report the current time.

        :param obj: the TemporaryJobs object that will be added to the database.
        """
        now_time = get_now_utc_datetime()
        obj.user = self.request.user
        obj.start_time = now_time
        obj.last_report = now_time


class JobUpdater(generics.UpdateAPIView):
    """
    Updates all the jobs that are curently running.
    """

    queryset = TemporaryJobs.objects.all()
    serializer_class = TemporaryJobsSerializer
    authentication_classes = (LWAuthBackend,)

    def get_object(self):
        """
        Gets from the list of TemporaryJobs the job that belongs to the user
        that made the request.

        :rtype: TemporaryJobs object.
        :raises: Http404 if the job is not found
        """
        try:
            obj = TemporaryJobs.objects.get(user=self.request.user)
            return obj
        except TemporaryJobs.DoesNotExist:
            raise Http404

    def pre_save(self, obj):
        """
        Sets the time for the last report as being the current time.
        """
        obj.last_report =  get_now_utc_datetime()

class JobTerminator(mixins.DestroyModelMixin, generics.GenericAPIView):
    """
    Stops a running job.
    """
    serializer_class = TemporaryJobsSerializer
    authentication_classes = (LWAuthBackend,)

    def get_object(self):
        """
        Gets from the list of TemporaryJobs the job that belongs to the user
        that made the request.

        :rtype: TemporaryJobs object.
        :raises: Http404 if the job is not found
        """
        try:
            obj = TemporaryJobs.objects.get(user=self.request.user)
            return obj
        except TemporaryJobs.DoesNotExist:
            raise Http404

    def move_job_to_finished(self, request):
        print request.DATA['details']
        """
        Adds a the details of a TemporaryJob object to one of the FinishedJobs
        objects and also updates the owed amount, taking into consideration
        how much the freelancer has worked for the current task.

        :param request: the HTTP request.
        :raises: HTTP_500_INTERNAL_SERVER_ERROR if something goes wrong.
        """
        try:
            temp_job = self.get_object()
            end_time = get_now_utc_datetime()

            # Add the job to the FinishedJobs table
            FinishedJobs.objects.create(
                user=request.user,
                start_time=temp_job.start_time,
                end_time=end_time,
                task_description=request.META.get('HTTP_X_MESSAGE', 'Undefined'),
                status="SUCCESSFUL",
            )

            # Update the owed amount
            wtime_in_seconds = (end_time-temp_job.start_time).total_seconds()
            pay_rate_per_second = request.user.pay_rate / 3600
            request.user.amount_owed += pay_rate_per_second * wtime_in_seconds
            request.user.save()

        except Exception as e:
            content = {'exception': e}
            return Response(content, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request, *args, **kwargs):
        """
        Handles the DELETE request. First of all, it adds a new entry to
        the FinishedJobs table and then it deletes the TemporaryJobs object.
        """
        self.move_job_to_finished(request)
        return self.destroy(request, *args, **kwargs)

class CredentialsChecker(generics.RetrieveAPIView):
    serializer_class = AccountsSerializer
    authentication_classes = (LWAuthBackend,)

    def get_object(self):
        """
        Checks the credentials of the searched user.

        :raises: Http404 if the user does not exist.
                 exceptions.PermissionDenied() if the user is disabled.
        """
        username = self.request.META.get('HTTP_X_USERNAME')
        password = self.request.META.get('HTTP_X_PASSWORD')

        try:
            user = Accounts.objects.get(user=username, password=password)
            if not user.enabled:
                raise exceptions.PermissionDenied()
        except Accounts.DoesNotExist:
            raise Http404









